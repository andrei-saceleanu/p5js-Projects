class Obstacle{
	constructor(){}

	show(){}
	intersect(particle,r){}


}